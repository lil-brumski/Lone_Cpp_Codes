#include <iostream>
#include <iomanip>

int main(){
	     int num = 1;
	     int lol = 47; 
	     while(num<1000001){
	    	std::cout<<std::setprecision(10);
	    	std::cout<<std::left;
	    	std::cout<<std::setfill('~');
std::cout<<std::setw(25)<<num<<std::setw(lol)<<"Hello, world!"<<std::endl;
	    num++;
	    }
	    std::cout<<"\n  Successful! You printed `Hello, world` 1 million times!"<<std::endl;
	   int num2=1;
	  while(num2<1000001){
	  	std::cout<<std::setprecision(7);
	  	std::cout<<std::left;
	  	std::cout<<std::setfill('~');
	  	std::cout<<std::setw(28)<<num2<<std::setw(lol)<<"I\'m a pro \U0001F606"<<std::endl;
	  	 num2++;
	  }
	     std::cout<<"You printed \"I\'m a pro \U0001F606\" 1 million times!"<<std::endl;
	  //std::cout<<"😃"<<std::endl;
	  //std::cout<<"\U0001F600"<<std::endl; 
}
