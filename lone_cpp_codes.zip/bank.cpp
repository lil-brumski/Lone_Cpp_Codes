#include <iostream>
#include <string>
#include <memory>
#include <vector>
#include <utility>

class DateOfBirth{
    private:
      int day;
      int month;
      int year;
    public:
      DateOfBirth(int d, int m, int y): day(d), month(m), year(y) {}
      
      void dob() const{
          std::cout << day << "/" << month << "/" << year << "\n";
      }
};


class Account{
  private:
    int accountNumber;
    int accountBalance;
    
  public:
    Account(int accountNo_, int accountBal) : accountNumber(accountNo_), accountBalance(accountBal) {}
    
    void account_display() const {       
           std::cout << "Account Number: " << accountNumber << "\n";                   
        std::cout << "Account Balance: ₦" << accountBalance << "\n";              
    }
    
};


class Customers{
    private:
      std::vector<std::string> customerNames;
      std::vector<DateOfBirth> dateOFbirth;
      std::vector<Account> accountDetails;
      
    public:
      Customers(const std::vector<std::string>& c, const std::vector<DateOfBirth>& d, const std::vector<Account>& a): customerNames(c), dateOFbirth(d), accountDetails(a) {}
    
    void customer_details() const{
        for(size_t cust = 0; cust < customerNames.size(); cust++){
            std::cout << "Customer\'s name: " << customerNames[cust] << "\n";
            
            std::cout << "Date of birth: ";
            dateOFbirth[cust].dob();
            
            accountDetails[cust].account_display();
            std::cout << std::endl;
        }
    }
    
};

int main() {
    {
        //Creating a vector of strings.
        std::vector<std::string> names;
        names.push_back("David");
        names.push_back("John");
        names.push_back("Peter");
        names.push_back("Mark");
        
        
        //Creating a vector of "DateOfBirth" data type
        std::vector<DateOfBirth> date_of_births = {
            DateOfBirth(3, 7, 1995),
            DateOfBirth(3, 3, 1996),
            DateOfBirth(19, 7, 1996),
            DateOfBirth(3, 1, 2007)
        };
        
        
        //Creating a vector of "Account" data type
        std::vector<Account> accounts = {
            Account(1110055555, 5000),
            Account(1110055556, 15000),
            Account(1110055585, 50600),
            Account(1110055600, 52500)
        };
        
        //Creating a "Customers" smart pointer.l
        auto customers = std::make_unique<Customers>(names, date_of_births, accounts);
        
        customers -> customer_details();   
        
    }
    
    return 0;
}