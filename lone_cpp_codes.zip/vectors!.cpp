#include <iostream>
#include <vector>
#include <cmath>

int main(){
     std::vector<std::vector<int>> matrix(50, std::vector<int>(10));
     
     for(size_t x = 0; x < 50; x++){
         for(size_t y = 0; y < 10; y++){
             matrix[x][y] = y * 5;
         }
     }
     
     for(size_t x = 0; x < 50; x++){
         for(size_t y = 0; y < 10; y++){
             std::cout<<matrix[x][y]<<" ";
         }
         std::cout<<std::endl;
     }
     
     
}