#include <iostream>
#include <limits>

template <typename T>
 T getInput(const std::string& prompt){
     T value;
     while(!(std::cout<<prompt && std::cin>>value)){
         std::cin.clear();
         std::cin.ignore(std::numeric_limits<std::streamsize>::max(),'\n');
         std::cerr<<"Invalid input, try again."<<std::endl;
     }
     return value;
 }
 
 int main(){
      int age = getInput<int>("Your age?: ");
      std::cout<<"You are "<<age<<" years old."<<std::endl;
 }