#include <iostream>
#include <string>

int main(){
    
    std::string name;
    std::cout<<"Enter your name: ";    
    getline(std::cin,name);
    
    while(name.empty()){
         std::cout<<"Enter your name: ";    
         getline(std::cin,name);
    }
 
    int space = 0;
    
    for(int x = 0; x < name.length(); x++){
        if(name[x] == ' '){
            space++;
        }
    }
    
    int len = name.length() - space;
    
    if(len > 1){
    std::cout<<"Your name is "<<len<<" letters long!\n";
    }
    else{
        std::cout<<"Your name is "<<len<<" letter long!\n";
    }
    
}