#include <iostream>
#include <random>
 
int main(){
    std::random_device rd;
    std::mt19937 gen(rd());
    
    std::uniform_int_distribution<int> distribution(1,20);
    
    int age = distribution(gen);
    
    std::cout<<"You are "<<age<<" years old."<<std::endl;
}