#include <iostream>
#include <limits>

int main() {
    double userInput;
    while (true) {
        std::cout << "Enter an number: ";
        std::cin >> userInput;

        if (std::cin.fail()) {
            std::cin.clear(); // Clear the error state
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Discard incorrect input
            std::cout << "Invalid input. Please enter an integer." << std::endl;
        } else {
            std::cout << "You entered: " << userInput << std::endl;
            break;
        }
    }

    return 0;
}