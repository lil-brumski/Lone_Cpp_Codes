#include <iostream>

void stu1(){
	       std::cout<<"Name: David Tamaratare Oghenebrume.\nAge: 16 years.\nGender: Male.\nHeight: 170cm.\n"<<std::endl;
}

void stu2(){
	       std::cout<<"Name: David Tamaralayefa Ogheneruno.\nAge: 14 years.\nGender: Male.\nHeight: 169cm.\n"<<std::endl;
}

int main(){
	    
	    int option;
	    while(!(option == 1 || option == 2)){	    	
	    	
	    std::cout<<"Which student`s info would you like you see?\nEnter a number from 0001 - 0002: ";
	        std::cin>>option;
	        std::cout<<std::endl;
	        
	        if(option == 1){
	        	stu1();
	        }
	        
	        else if(option == 2){
	        	stu2();
	        }
	        
	        else{
	        	std::cout<<"Invalid option!"<<std::endl;
	        	break;
	        }	        
	    }
	    
	    std::cout<<"Ratio + L + Bozo + I don`t care!"<<std::endl;
	    
}