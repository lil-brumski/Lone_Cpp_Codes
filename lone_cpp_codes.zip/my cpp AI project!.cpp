#include <iostream>
#include <cmath>
#include <string>
#include <iomanip>

int main(){
	    //God, this code is scary to look at, help me 😭😭
	    //Title of the AI application.
	    std::cout<<"Brumsky A.I. by David Tamaratare Oghenebrume."<<std::endl;
	    std::cout<<std::endl;	  
	    
	    std::cout<<"This application is for solving mainly mathematics."<<std::endl;  
	    std::cout<<" "<<std::endl;
	    
	    std::string user_name;
	    std::cout<<"Enter your full name: ";
	    //Prompts the user to enter their name.
	    std::getline(std::cin,user_name);
	    std::cout<<" "<<std::endl;
	    
	    int user_age;
	    std::cout<<"Enter your age: ";
	    std::cin>>user_age;
	    while(user_age<13){
	    	std::cout<<"\nYou don't meet the minimum age requirement for this service!"<<std::endl;
	    	return 0;
	    }
	    std::cout<<std::endl;
	    
	    std::string gender;
	    std::cout<<"Enter your gender(`Male`, `Female`, `N/A`): ";
	    std::cin>>gender;
	    while(gender != "Male" && gender != "Female" && gender != "N/A"){
	    	       std::cout<<"\nCouldn't get that, try again: ";
	    	       std::cin>>gender;	    
	   }
	   std::cout<<std::endl;
	    
	    std::cout<<"Hey there Master "<<user_name<<", I\'m Brumsky A.I., your personal assistant, how can I help you?"<<std::endl;
	    //This guy below is for declaring of a string variable called 'option_s'
	    std::string option_s;
	    std::cout<<" "<<std::endl;
	    
	    std::cout<<"(Options: `BM` for \"Basic-maths\", `LTM` for \"Logarithm-type-maths\",  `EX` for \"Exponents\", `PRO` for \"Profile\"- We are working on more options, so stay tuned!)- You have 5 tries: "<<std::endl;
	    //Prompts the user to enter an option.
	    std::cin>>option_s;
	    std::cout<<std::endl;
	   //User has only 5 tries. 
	    int count_down;
	    count_down=5;
	    
	    //A while-loop that checks if the user entered any of the options above.
	    while(count_down!=0){
	    	
	    	//This if-statement checks if the user entered "Basic-maths."
/*1*/    	if(option_s == "BM"){
	    		 char oper1;
	    		 double num1, num2;
	    		 std::cout<<"Enter number: ";
	    std::cin>>num1;
	    std::cout<<"Enter operator (+, -, *, /, ): ";
	    std::cin>>oper1;
	    std::cout<<"Enter second number: ";
	    std::cin>>num2;	 

	    	       //Start of If-statement in BM option.
	            //Checks the user's oper1 input  
	            if(oper1 == '+'){
	    	           std::cout<<num1<<" + "<<num2<<" = ";
	    	         std::cout<<num1 + num2<<std::endl;	
	    	         //std::cout<<"Tries left: "<<count_down<<"."<<std::endl;	   
	    	         if(count_down==0){
	                   	break;
	              }   
	    	          }	    	            
	    	            	    	            	    	            
	               //else if 1 of BM option. 
	               //Checks the user's oper1 input
	              else if(oper1 == '-'){
	    	          std::cout<<num1<<" - "<<num2<<" = ";
	    	          std::cout<<num1 - num2<<std::endl;    
	    	            //std::cout<<"Tries left: "<<count_down<<"."<<std::endl;	  	 
	    	            if(count_down==0){
	                   	break;
	              }   	            
	               }
	 
	                                 
	              //Checks the user's oper1 input
	              else if(oper1 == '*'){
	    	          std::cout<<num1<<" * "<<num2<<" = ";
	              	std::cout<<num1 * num2<<std::endl;  
	              	  //std::cout<<"Tries left: "<<count_down<<"."<<std::endl;	  
	              	  if(count_down==0){
	                   	break;
	              }           	    
	                }
	                  
	              //Checks the user's oper1 input
	              else if(oper1 == '/'){
	                     //Checks if the user's num2 is != 0
	    	                if(num2 != 0){
	           	       std::cout<<num1<<" / "<<num2<<" = ";
	                 	std::cout<<num1 / num2<<std::endl;
	                 	  //std::cout<<"Tries left: "<<count_down<<"."<<std::endl;	 
	                 	  if(count_down==0){
	                   	break;
	              }
	    	              }
	    	               else{
	    	    	        std::cout<<"Bruh...are you trying to divide by zero 💀"<<std::endl;
	    	    	          //std::cout<<"Tries left: "<<count_down<<"."<<std::endl;	 
	    	    	          if(count_down==0){
	                   	break;
	              }
	    	           }
	    	           
	    	      }
	    	      
	    	      //Will display when the operator is invalid.
	    	     else{
	           		std::cout<<"Invalid operand!"<<std::endl;
	           		  //std::cout<<"Tries left: "<<count_down<<"."<<std::endl;	 
	           		  if(count_down==0){
	                   	break;
	              }
	           	}
	  }




	  	  //This else-if-statement checks if the user entered "Logarithm-type-maths."
/*2*/	    	else if(option_s == "LTM"){
	    		      std::cout<<"\nGetting logarithms of numbers. "<<std::endl;	    
	    double base;
	    std::cout<<"Enter the base you want to work with: ";
	    std::cin>>base;	    
	    double number;
	    std::cout<<"Enter the number that you want to check the log of in the base you inputted: ";
	    std::cin>>number;	    
	    std::cout<<std::setprecision(4);    
	    std::cout<<"The log of "<<number<<" with a base of "<<base<<" is "<<std::log(number)/std::log(base)<<"!"<<std::endl;	  
	      //std::cout<<"Tries left: "<<count_down<<"."<<std::endl;	 
	      if(count_down==0){
	                   	break;
	              } 
	    
	  	}

	    	
	    		    	
	    		    		    		    	
	    	//This else-if-statement checks if the user entered "Exponents."
/*3*/	    	else if(option_s == "EX"){
	    		double num999;
	    		double power999;
	    		std::cout<<"\nEnter number: ";
	    		std::cin>>num999;
	    		std::cout<<"Enter exponent: ";
	    		std::cin>>power999;
	    		std::cout<<num999<<" raise to the power of "<<power999<<" is "<<std::pow(num999,power999)<<std::endl;	   	     //std::cout<<"Tries left: "<<count_down<<"."<<std::endl;	 
	    		if(count_down==0){
	                   	break;
	              }
	    	}

	    	

	    		 
/*4*/	    		    else if(option_s == "PRO"){
	    		    		std::cout<<std::left;
	    		    		std::cout<<std::setfill('-');
	    		    		int wth;
	    		    		wth = 35;
	std::cout<<"PROFILE: "<<std::endl;    		    		std::cout<<std::setw(wth)<<"Name"<<std::setw(wth)<<user_name<<std::endl;
	    		    		std::cout<<std::setw(wth)<<"Age"<<std::setw(wth)<<user_age<<std::endl;
	    		    		std::cout<<std::setw(wth)<<"Gender"<<std::setw(wth)<<gender<<std::endl;
	    		    		//std::cout<<"Tries left: "<<count_down<<"."<<std::endl;	 
	    		if(count_down==0){
	                   	break;
	              }		    		
	        }    		    		    		    	   		    		    		    		    			    		    		    		    	
	    		    		    		    		    		    	   		    		    		    		    	
    		    		    		    		    		    	   		    		    		    		    	   		    		    		    		    		    		    		    		    		    		    	   		    		    		    		    	   		    		    		    		    	   		    		    		    		    	   		    		    		    		    	
	    	//If the user's input is not any of the options then it will execute what is in this else-statement.
/*5*/	    	else{
	    			//count_down--;
	    			  if(count_down==0){
	                   	break;
	              }
	    			std::cout<<"Wrong or invalid input!"<<std::endl;
	    	  //std::cin>>option_s;
	    	  //std::cout<<"Tries left: "<<count_down<<"."<<std::endl;	    	     	 
	 }
	    	
	    	
	    	
	           //...
	       //count_down--;
	       std::cout<<"Tries left: "<<--count_down<<"."<<std::endl;	 
	                   if(count_down==0){
	                   	break;
	                   }
	                   
	                   std::cout<<std::endl;
	    	              std::cout<<"Do you wish to continue?"<<std::endl;
	    	              std::string another_o;	    	              	    	              
	    	              std::cout<<"Type yes or no: ";
	    	              std::cin>>another_o;
	    	              std::cout<<std::endl;
	    	              
	    	              if(another_o == "yes"){
	    	              	   std::cout<<"Enter one of the options again: `BM` for \"Basic-maths\", `LTM` for \"Logarithm-type-maths\",  `EX` for \"Exponents\", `PRO` for \"Profile\"-: ";
	    	              	   std::cin>>option_s;
	    	              }
	    	              
	    	              else if(another_o == "no"){
	    	              	         std::cout<<"End of program."<<std::endl;
	    	              	         return 0;
	    	              }
	    	              
	    	              else{	    
	    	              std::cout<<"Invalid, try again!"<<std::endl;
	    	              	 std::cin>>another_o;              	 
	    	              	 while(another_o != "yes" || another_o != "no"){
	    	              	 	      
	    	              	 	      if(another_o == "yes"){
	    	              	   std::cout<<"Enter one of the options again: `BM` for \"Basic-maths\", `LTM` for \"Logarithm-type-maths\",  `EX` for \"Exponents\", `PRO` for \"Profile\": ";
	    	              	   std::cin>>option_s;
	    	              }
	    	              else if(another_o == "no"){
	    	              	         std::cout<<"End of program."<<std::endl;
	    	              	         return 0;
	    	              }
	    	              else{
	    	              	 	     std::cout<<"Invalid, try again!"<<std::endl;
	    	              	 std::cin>>another_o;
	    	              }
	    	              
	    	      	 }   	              	
	    
	         } 	 
	    	             //......	    	     
	   
 }
          	 
	    //End of while loop. 
	   //Outside the while loop.
	   std::cout<<"Your session has automatically ended since you have exhausted your 5 tries!"<<std::endl;
	      return 0;
 }