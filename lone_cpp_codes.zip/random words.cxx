#include <iostream>
#include <random>

int main() {
    std::string wordArray[] = {"apple", "banana", "orange", "grape", "kiwi"};

    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<int> distribution(0, 4); // Adjust the upper limit accordingly

    // Generate and print random words
    for (int i = 0; i < 5; ++i) {
       int randomIndex = distribution(gen);
        std::cout << "Random Word: " << wordArray[randomIndex] << std::endl;
    }

    return 0;
}