#include <iostream>
#include <string>

int main(){	    

	    char arr[10];	  
	      
	    for(size_t i = 0; i < 10; i++){
	    	     std::cout<<"arr["<<i<<"]: "<<i+1<<std::endl;
	    }
	    
	    	       std::cout<<"Memory address of arr[10] is "<<&arr<<"!"<<std::endl;
	    	       
	    	       std::cout<<std::endl;
	       
	      std::string name[5] = {"David", "Tamaratare", "Oghenebrume"};
	      name[3] = "Brumski";
	            
	      for(size_t b = 0; b < 4; b++){
	      std::cout<<"name["<<b<<"]: " <<"\""<<name[b]<<"\""<<std::endl;
	      std::cout<<"Memory address of name["<<b<<"] is "<<&name[b]<<std::endl;
	      std::cout<<std::endl;
	      }
	      
	      size_t size = 10;
	      int *p_o = new(std::nothrow) int[size]{1,2,3,4,5};
	      
}