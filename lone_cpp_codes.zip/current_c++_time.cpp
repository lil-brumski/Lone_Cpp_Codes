#include <iostream>
#include <chrono>
#include <thread>

void TIME(){
    std::this_thread::sleep_for(std::chrono::seconds(1));
    }
    
int main(){
      
      
      for(int x = 0; x < 60; x++){
           auto now = std::chrono::system_clock::now();
      
           auto time_now = std::chrono::system_clock::to_time_t(now);
      
           std::cout<<"The time right now is: "<<std::ctime(&time_now)<<std::endl;
      
           TIME();
      }
      
}