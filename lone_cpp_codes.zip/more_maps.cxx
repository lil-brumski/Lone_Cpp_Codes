#include <iostream>
#include <map>

int main(){
    std::map<int, std::string> deez = {
        {1, "one"}, {2, "two"}, {3, "three"}, {4, "four"},
        {5, "five"}, {6, "six"}, {7, "seven"}, {8, "eight"}
        };
     
    for(int x = 1; x <= std::size(deez); x++){   
         std::cout<<"Number: "<<deez[x]<<std::endl;;
    }
    
    
}