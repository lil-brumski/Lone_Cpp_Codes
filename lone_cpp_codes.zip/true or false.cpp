#include <iostream>
using namespace std;

int main(){
	    int special_num = 23;
	    cout << "Number-Guessing game, you have 5 attempts"<<endl;
	    int your_guess;
	   // cout<<"Enter your guess: ";
	   // cin>>your_guess;
	    int attempts = 0;
	    int limit = 5;
	    bool end_program = false;
	    while(special_num != your_guess && !end_program){
	    	if(attempts<limit){
	    		  cout << "Enter your guess: ";
	    		  cin>>your_guess;
	    		  attempts++;
	    	}
	    	else{
	    		  end_program = !false;
	    	}
	 }
	 
	 
	 
	 if(end_program){
	 	  cout << "You lose!";
	 }
	 else{
	 	       cout << "You win!";
	 }
	 return 0;
}