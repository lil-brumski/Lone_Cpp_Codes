#include <iostream>
using namespace std;

//There are 5 students seeking admission, you are to input random values between 0 and 100 for each of them, tap the RUN button and enter their values in five different lines.

int main() {
    double max_score = 100.0;
    double cut_off = 59.0;
    double stud1, stud2, stud3, stud4, stud5;
    cin>>stud1>>stud2>>stud3>>stud4>>stud5;
    if(stud1 >= cut_off && stud1 <= max_score){
        cout << "Student 1 has been admitted!"<<endl;
    }
    else if(stud1>= 0 && stud1 < cut_off){
        cout << "Student 1 has not been admitted"<<endl;
    }
    else{
        cout << "Invalid input from Student 1"<<endl;
    }
    
    if(stud2 >= cut_off && stud2 <= max_score){
        cout << "Student 2 has been admitted!"<<endl;
    }
    else if(stud2>= 0 && stud2 < cut_off){
        cout << "Student 2 has not been admitted"<<endl;
    }
    else{
        cout << "Invalid input from Student 2"<<endl;
    }
    
    if(stud3 >= cut_off && stud3 <= max_score){
        cout << "Student 3 has been admitted!"<<endl;
    }
    else if(stud3>= 0 && stud3 < cut_off){
        cout << "Student 3 has not been admitted"<<endl;
    }
    else{
        cout << "Invalid input from Student 3"<<endl;
    }
    
    if(stud4 >= cut_off && stud4 <= max_score){
        cout << "Student 4 has been admitted!"<<endl;
    }
    else if(stud4>= 0 && stud4 < cut_off){
        cout << "Student 4 has not been admitted"<<endl;
    }
    else{
        cout << "Invalid input from Student 4"<<endl;
    }
    
    if(stud5 >= cut_off && stud5 <= max_score){
        cout << "Student 5 has been admitted!"<<endl;
    }
    else if(stud5>= 0 && stud5 < cut_off){
        cout << "Student 5 has not been admitted"<<endl;
    }
    else{
        cout << "Invalid input from Student 5"<<endl;
    }
    return 0;
}