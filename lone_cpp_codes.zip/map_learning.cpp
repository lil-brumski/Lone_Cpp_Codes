#include <iostream>
#include <string>
#include <map>

int main(){
    
    std::map<std::string, int> deez = {        
        {"one", 1}, {"two", 2}, {"three", 3}
    };
    
    std::cout<<deez["three"];
}