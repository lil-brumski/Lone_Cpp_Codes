#include <iostream>
#include <string>
#include <memory>

class DOB{
    private:
      int day;
      std::string month;
      int year;
      
    public:
      DOB(const int& d = 6, const std::string& m = "March", const int y = 1991) : day(d), month(m), year(y) {}
      
      void dob_about() const {
          
          if(day == 1){
          std::cout<<"Date of Birth: "<<day<<"st of "<<month<<", "<<year<<"."<<std::endl;
               }
           else if(day == 2){
          std::cout<<"Date of Birth: "<<day<<"nd of "<<month<<", "<<year<<"."<<std::endl;
               }
            else if(day == 3){
          std::cout<<"Date of Birth: "<<day<<"rd of "<<month<<", "<<year<<"."<<std::endl;
               }
             else{
          std::cout<<"Date of Birth: "<<day<<"th of "<<month<<", "<<year<<"."<<std::endl;
               }
               
          }
    };
    
class Gender{
    private:
      //1 rep. male while 0 rep. female.
      bool _gender;
      
    public:
      Gender(const bool& g = 0) : _gender(g) {}
      
      void gen_about() const {
          if(_gender){
          std::cout<<"Gender: Male."<<std::endl;
            }
          else{
              std::cout<<"Gender: Female."<<std::endl;
              }
          }
    };
    
class Student{
    private:
      std::string name;
    
    public:
      DOB dob;
      Gender gender;
      
      Student(const std::string& n = "Dignity Hope") : name(n) {}
      
      void stu_about() const {
          std::cout<<"Name: "<<name<<std::endl;
          dob.dob_about();
          gender.gen_about();
          }
    };
    
int main(){
    
    {
    std::unique_ptr<Student> student = std::make_unique<Student>();
    
    student->stu_about();
    }
    
}