#include <iostream>
#include <random>
#include <string>
#include <vector>

int main(){
    
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<int> distribution(0,4);
    
   int ran;
    std::vector<std::string> Words = {"Hi, how can I help you?", "How are you doing today?", "Hey there, how're you doing?", "Can I be of help to you?"};
   
   std::string user_input;
   
    while(true){
        ran = distribution(gen);
        std::cout<<Words[ran]<<std::endl;
        std::cin>>user_input;
        } 
    
}