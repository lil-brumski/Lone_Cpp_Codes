#include <iostream>
#include <vector>
#include <numeric>
#include <chrono>

int sum_array(const std::vector<int>& arr) {
    return std::accumulate(arr.begin(), arr.end(), 0);
}

int main() {
    std::vector<int> array(1000000, 1); // Creating an array with a million elements, all set to 1
    auto start = std::chrono::steady_clock::now();
    int result = sum_array(array);
    auto end = std::chrono::steady_clock::now();
    std::cout << "Sum: " << result << std::endl;
    std::cout << "Time taken: " << std::chrono::duration_cast<std::chrono::microseconds>(end - start).count() << " microseconds" << std::endl;
    return 0;
}