#include <iostream>
#include <iomanip>

int main(){
	    int a = 36;
	    int b = 32;
	    std::cout<<std::setfill('.');
	    
	    //B
	    std::cout<<std::right<<std::setw(a)<<"************"<<std::left<<std::setw(a)<<"************"<<std::endl;
	    
	    std::cout<<std::right<<std::setw(a)<<"************"<<std::left<<std::setw(a)<<"*************"<<std::endl;
	    
	    std::cout<<std::right<<std::setw(a)<<"********...."<<std::left<<std::setw(a)<<"....**********"<<std::endl;
	    
	    std::cout<<std::right<<std::setw(a)<<"********...."<<std::left<<std::setw(a)<<"....**********"<<std::endl;
	    
	    std::cout<<std::right<<std::setw(a)<<"********...."<<std::left<<std::setw(a)<<"....**********"<<std::endl;
	    
	    std::cout<<std::right<<std::setw(a)<<"********...."<<std::left<<std::setw(a)<<"....*********"<<std::endl;
	    
	    std::cout<<std::right<<std::setw(a)<<"************"<<std::left<<std::setw(a)<<"************"<<std::endl;
	    
	    std::cout<<std::right<<std::setw(a)<<"************"<<std::left<<std::setw(a)<<"************"<<std::endl;
	    
	    std::cout<<std::right<<std::setw(a)<<"************"<<std::left<<std::setw(a)<<"**************"<<std::endl;
	    
	  std::cout<<std::right<<std::setw(a)<<"********...."<<std::left<<std::setw(a)<<"......********"<<std::endl;
	  
	  std::cout<<std::right<<std::setw(a)<<"********...."<<std::left<<std::setw(a)<<"......*********"<<std::endl;
	  
	  std::cout<<std::right<<std::setw(a)<<"********...."<<std::left<<std::setw(a)<<"......**********"<<std::endl;
	  
	  std::cout<<std::right<<std::setw(a)<<"********...."<<std::left<<std::setw(a)<<"......**********"<<std::endl;
	  
	  std::cout<<std::right<<std::setw(a)<<"********...."<<std::left<<std::setw(a)<<"......**********"<<std::endl;
	  
	  std::cout<<std::right<<std::setw(a)<<"********...."<<std::left<<std::setw(a)<<"......**********"<<std::endl;
	  
	  std::cout<<std::right<<std::setw(a)<<"************"<<std::left<<std::setw(a)<<"***************"<<std::endl;
	  
	  std::cout<<std::right<<std::setw(a)<<"************"<<std::left<<std::setw(a)<<"**************"<<std::endl;
	  
	     for(int p = 1; p < 3; p++){	  
	     std::cout<<std::setfill('.');   	
	   std::cout<<std::right<<std::setw<<"............"<<std::left<<std::setw(a)<<"................."<<std::endl;
	         }
	  
	  //R
	  	  std::cout<<std::right<<std::setw(a)<<"************"<<std::left<<std::setw(a)<<"************"<<std::endl;
	    
	    std::cout<<std::right<<std::setw(a)<<"************"<<std::left<<std::setw(a)<<"*************"<<std::endl;
	    
	    std::cout<<std::right<<std::setw(a)<<"********...."<<std::left<<std::setw(a)<<"....**********"<<std::endl;
	    
	    std::cout<<std::right<<std::setw(a)<<"********...."<<std::left<<std::setw(a)<<"....**********"<<std::endl;
	    
	    std::cout<<std::right<<std::setw(a)<<"********...."<<std::left<<std::setw(a)<<"....**********"<<std::endl;
	    
	    std::cout<<std::right<<std::setw(a)<<"********...."<<std::left<<std::setw(a)<<"....*********"<<std::endl;
	    
	    std::cout<<std::right<<std::setw(a)<<"************"<<std::left<<std::setw(a)<<"************"<<std::endl;
	    
	    std::cout<<std::right<<std::setw(a)<<"************"<<std::left<<std::setw(a)<<"************"<<std::endl;
	    
	    std::cout<<std::right<<std::setw(a)<<"************"<<std::left<<std::setw(a)<<"**************"<<std::endl;
	    
	  std::cout<<std::right<<std::setw(a)<<"********...."<<std::left<<std::setw(a)<<"......********"<<std::endl;
	  
	  std::cout<<std::right<<std::setw(a)<<"********...."<<std::left<<std::setw(a)<<"......*********"<<std::endl;
	  
	  std::cout<<std::right<<std::setw(a)<<"********...."<<std::left<<std::setw(a)<<"......**********"<<std::endl;
	  
	  std::cout<<std::right<<std::setw(a)<<"********...."<<std::left<<std::setw(a)<<"......**********"<<std::endl;
	  
	  std::cout<<std::right<<std::setw(a)<<"********...."<<std::left<<std::setw(a)<<"......**********"<<std::endl;
	  
	  std::cout<<std::right<<std::setw(a)<<"********...."<<std::left<<std::setw(a)<<"......**********"<<std::endl;
	  
	  std::cout<<std::right<<std::setw(a)<<"********...."<<std::left<<std::setw(a)<<"......**********"<<std::endl;
	  
	  std::cout<<std::right<<std::setw(a)<<"********...."<<std::left<<std::setw(a)<<"......**********"<<std::endl;	  	 
	  
	  
	  
	  for(int p = 1; p < 3; p++){	  
	     std::cout<<std::setfill('.');   	
	   std::cout<<std::right<<std::setw<<"............"<<std::left<<std::setw(a)<<"................."<<std::endl;
	         }
	  
	       //U
	       for(int o = 1; o < 15; o++){
	        std::cout<<std::setfill('.');
	        std::cout<<std::right<<std::setw(a)<<"********...."<<std::left<<std::setw(a)<<"......********"<<std::endl;  
	        } 
	        
	       std::cout<<std::right<<std::setw(a)<<".*******...."<<std::left<<std::setw(a)<<"......*******."<<std::endl;  
	       
	        std::cout<<std::right<<std::setw(a)<<"..**********"<<std::left<<std::setw(a)<<"************.."<<std::endl;
	        
	        std::cout<<std::right<<std::setw(a)<<"...*********"<<std::left<<std::setw(a)<<"***********.."<<std::endl;
	        
	        
	        
	        for(int p = 1; p < 3; p++){	  
	     std::cout<<std::setfill('.');   	
	   std::cout<<std::right<<std::setw<<"............"<<std::left<<std::setw(a)<<"................."<<std::endl;
	         }
	         
	         
	         
	         //M
	         std::cout<<std::right<<std::setw(a)<<"***********."<<std::left<<std::setw(a)<<".***********"<<std::endl;
	         
	         std::cout<<std::right<<std::setw(a)<<"************"<<std::left<<std::setw(a)<<"************"<<std::endl;
	         
	         for(int m = 1; m < 16; m++){
	         	std::cout<<std::setfill('.');
	         std::cout<<std::right<<std::setw(a)<<"*****....***"<<std::left<<std::setw(a)<<"***....*****"<<std::endl;
	        } 
	       
	         
	           for(int p = 1; p < 3; p++){	  
	     std::cout<<std::setfill('.');   	
	   std::cout<<std::right<<std::setw<<"............"<<std::left<<std::setw(a)<<"................."<<std::endl;
	         }
	         
	         
	         //E
	         for(int i = 1; i < 5; i++){
	               std::cout<<std::setfill('.');
	               std::cout<<std::right<<std::setw(a)<<"************"<<std::left<<std::setw(a)<<"************"<<std::endl;
	         }
	         
	         for(int i = 1; i < 4; i++){
	         	     std::cout<<std::setfill('.');
	         	     std::cout<<std::right<<std::setw(b)<<"********"<<std::left<<std::setw(a)<<"................"<<std::endl;
	         }
	      
	          for(int i = 1; i < 4; i++){
	               std::cout<<std::setfill('.');
	               std::cout<<std::right<<std::setw(a)<<"************"<<std::left<<std::setw(a)<<"************"<<std::endl;
	         }  
	         
	          for(int i = 1; i < 4; i++){
	         	     std::cout<<std::setfill('.');
	         	     std::cout<<std::right<<std::setw(b)<<"********"<<std::left<<std::setw(a)<<"................"<<std::endl;
	         } 
	         
	          for(int i = 1; i < 5; i++){
	               std::cout<<std::setfill('.');
	               std::cout<<std::right<<std::setw(a)<<"************"<<std::left<<std::setw(a)<<"************"<<std::endl;
	         }
	         
	         
	         
	           for(int p = 1; p < 3; p++){	  
	     std::cout<<std::setfill('.');   	
	   std::cout<<std::right<<std::setw<<"............"<<std::left<<std::setw(a)<<"................."<<std::endl;
	         }
	        
	     std::cout<<"\nBy David Tamaratare Oghenebrume.\nIt took like 1hr+ to do!"<<std::endl;   
	           
}