#include <iostream>
#include <iomanip>
#include <cctype>

void NAME(std::string name, std::string mat_num,double g_p_a){
         std::cout<<"Name: "<<name<<std::endl;
         std::cout<<"Matric. Number: "<<mat_num<<std::endl;
         std::cout<<std::setprecision(3)<<"Your current semester GPA is "<<g_p_a<<std::endl;
}

int main(){
	double A = 5.00, B = 4.00, C = 3.00, D = 2.00, E = 1.00, F = 0.00;
	char math, eng, phy, chem;
	
	//The courses and their units.
	double mth = 3.00, eg = 2.00, ph = 3.00, ch = 2.00;
	
	//Total course units.
	double total_course_units = 10;
	
	//String values for storing the values of the student's name and matric number.
	std::string n, m;
	
	//Stores GPA 
	double gpa;
	
	std::cout<<"Enter your name: ";
    std::getline(std::cin,n);
    
    std::cout<<"Enter your matric number: ";
    std::cin>>m;

    
                
     //MATHEMATICS        
    std::cout<<"Enter your grades in the following courses: Mathematics: ";
    std::cin>>math;
    math = std::toupper(math);
    
    //Checks the grade entered for 'math'
    while(math != 'A' && math != 'B' && math != 'C' && math != 'D' && math != 'E' && math != 'F'){
      std::cout<<"Invalid option, try again"<<std::endl;
      std::cout<<"Enter your grades in the following courses: Mathematics: ";
    std::cin>>math;
    math = std::toupper(math);   
   } 
   
   if(math == 'A'){
        mth *= A; 
    }
    else if(math == 'B'){
        mth *= B;
    }
    else if(math == 'C'){
        mth *= C;
    }
    else if(math == 'D'){
        mth *= D;
    }
    else if(math == 'E'){
        mth *= E;
    }
    else if(math == 'F'){
        mth *= F;
       }
   
   
   
   //ENGLISH LANGUAGE.
    std::cout<<"English Language: ";
   std::cin>>eng;
   eng = std::toupper(eng);
   
    //Checks the grade entered for 'eng'
    while(eng != 'A' && eng != 'B' && eng != 'C' && eng != 'D' && eng != 'E' && eng != 'F'){
     if(eng == 'A'){
        eg *= A; 
    }
    else if(eng == 'B'){
        eg *= B;
    }
    else if(eng == 'C'){
        eg *= C;
    }
    else if(eng == 'D'){
        eg *= D;
    }
    else if(eng == 'E'){
        eg *= E;
    }
    else if(eng == 'F'){
        eg *= F;
    }
    else{
      std::cout<<"Invalid option, try again"<<std::endl;
      std::cout<<"Enter your grades in the following courses: English Language: ";
    std::cin>>eng;
    eng = std::toupper(eng);
        }
   } 
    
  
    //PHYSICS  
    std::cout<<"Physics: ";
    std::cin>>phy;
     phy = std::toupper(phy);
    
    //Checks the grade entered for 'phy'
    while(phy != 'A' && phy != 'B' && phy != 'C' && phy != 'D' && phy != 'E' && phy != 'F'){
     if(phy == 'A'){
        ph *= A; 
    }
    else if(phy == 'B'){
        ph *= B;
    }
    else if(phy == 'C'){
        ph *= C;
    }
    else if(phy == 'D'){
        ph *= D;
    }
    else if(phy == 'E'){
        ph *= E;
    }
    else if(phy == 'F'){
        ph *= F;
    }
    else{
      std::cout<<"Invalid option, try again"<<std::endl;
      std::cout<<"Enter your grades in the following courses: Physics: ";
    std::cin>>phy;
     phy = std::toupper(phy);
        }    
   } 
    
    
    
    //CHEMISTRY
    std::cout<<"Chemistry: ";
    std::cin>>chem;
    chem = std::toupper(chem);
    
    //Checks the grade entered for 'chem'
    while(chem != 'A' && chem != 'B' && chem != 'C' && chem != 'D' && chem != 'E' && chem != 'F'){
    if(chem == 'A'){
        ch *= A; 
    }
    else if(chem == 'B'){
        ch *= B;
    }
    else if(chem == 'C'){
        ch *= C;
    }
    else if(chem == 'D'){
        ch *= D;
    }
    else if(chem == 'E'){
        ch *= E;
    }
    else if(chem == 'F'){
        ch *= F;
    }
    else{
      std::cout<<"Invalid option, try again"<<std::endl;
      std::cout<<"Enter your grades in the following courses: Chemistry: ";
    std::cin>>phy;
    chem = std::toupper(chem);
        }     
   } 
   
   
   
    gpa = (mth + eg + ph + ch)/total_course_units;
	NAME(n,m,gpa);
	
}