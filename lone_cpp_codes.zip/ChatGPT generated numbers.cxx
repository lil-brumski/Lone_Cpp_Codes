#include <iostream>
#include <random>

int main() {
    // 1. Create a Mersenne Twister engine (rng) and seed it
    std::random_device rd;
    std::mt19937 rng(rd());

    // 2. Create a distribution for random integers between 1 and 100
    std::uniform_int_distribution<int> distribution(1, 100);

    // 3. Generate a random number using the distribution and engine
    int randomNum = distribution(rng);

    // 4. Print the generated random number
    std::cout << "Random Number: " << randomNum << std::endl;

    return 0;
}