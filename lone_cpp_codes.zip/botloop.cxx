#include <iostream>

int main(){
	    
	    for(int x = 1; x < 101; x++){
	    	std::cout<<"Bot444"<<std::endl;
	    }
	    
	    return 0;
}