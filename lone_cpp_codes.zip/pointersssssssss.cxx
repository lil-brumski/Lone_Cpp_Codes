#include <iostream>

void Pon(){	 
      //Giving `size` a value.     
	    const size_t size = 4;	   
	    //Declaring a pointer that's an array.
	    double *poi = new(std::nothrow) double[size]{1.5,3.0,4.5,6.0};	  
	    //Creating a for-loop for getting its values.
	    for(size_t i = 0; i < size; i++){
	    	std::cout<<"Value: "<<poi[i]<<" : "<<*(poi + i)<<std::endl;
	    }	  
	    //Freeing memory. 
	    delete [] poi;
	    //Resetting the pointer's values to zero.'
	    poi = nullptr;
}

int main(){
	    //Nullptr.
	    int *ptr = nullptr;
	    //Try-catch block for handling dereferencing of a null pointer.
	    try{
	          if(ptr == nullptr){
	              throw 
	              std::runtime_error("Invalid initialisation of pointer.");
	            }
	         std::cout<<*ptr<<std::endl;
	       }
	   catch(const std::exception& err){
	              std::cerr<<"Error: "<<err.what()<<std::endl;
	       }	       
	    //Calling the function above.
	    Pon();
	    //Shows the program ended successfully.
	    return 0;	   
}