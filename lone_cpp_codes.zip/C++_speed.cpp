#include <iostream>
#include <chrono>
#include <cmath>
#include <atomic>

std::atomic<double> hold = 0.0;

void compute() {
    double result = 0.0;
    for (int i = 0; i < 1e8; ++i) {
        result += std::sin(i) * std::cos(i);
    }
    hold.store(result);
}

int main() {
    // Record the start time
    auto start = std::chrono::high_resolution_clock::now();

    // Perform the computation
    compute();
    double result = hold.load();
    // Record the end time
    auto end = std::chrono::high_resolution_clock::now();

    // Calculate the elapsed time
    std::chrono::duration<double> elapsed = end - start;

    // Output the elapsed time in seconds
    std::cout << "C++ elapsed time: " << elapsed.count() << " seconds\n";
    std::cout << "Result: " << result << std::endl;

    return 0;
}