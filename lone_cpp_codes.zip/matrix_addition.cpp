#include <iostream>
#include <vector>

int main(){
    std::vector<std::vector<int>> mat1 = {
        {1, 2, 3, 4},
        {5, 6, 7, 8},
        {9, 10, 11, 12}
        };
        
    std::vector<std::vector<int>> mat2 = {
        {12, 11, 10, 9},
        {8, 7, 6, 5},
        {4, 3, 2, 1}
        };
        
     std::vector<std::vector<int>> res(3, std::vector<int>(4,0));
     
     for(int j = 0; j < 3; j++){
         for(int k = 0; k < 4; k++){
             res[j][k] = mat1[j][k] + mat2[j][k];
         }
     }
     
     for(int x = 0; x < 3; x++){
         for(int y = 0; y < 4; y++){
             std::cout<<res[x][y]<<" ";
         }
         std::cout<<std::endl;
     }
     
}