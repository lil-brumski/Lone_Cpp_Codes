#include <iostream>
#include <fstream>
#include <string>

int main(){
	
	    // Open the file for reading
	    std::ifstream CppFile("/storage/emulated/0/Documents/Cxxdroid/brumsky-CPU.cpp");

	   // Check if the file is open
   	if (CppFile.is_open()){
		      std::string line;

		       // Read and print each line in the file
		       while (getline(CppFile, line)){
			                 std::cout << line << '\n';
		                  }

		      // Close the file when done
		      CppFile.close();
	       }
	       
  	else{
		       std::cerr << "Error: Unable to open the file for reading.\n";
		       return 1; // Return an error code
	        }

	return 0; // Return success code
}