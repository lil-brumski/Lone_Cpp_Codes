#include <iostream>
#include <stdexcept>

int main() {    
    
    try{
         int x = 5;
         double y = 0;
         if(y == 0){
         	  throw
         	          std::runtime_error("Division by zero is not allowed!");
                      }
                      double z = x / y; // Division by zero, which causes a runtime error
                      std::cout<<"z is equal to: "<<z<<std::endl;
         }
   catch(const std::exception& e){
              std::cerr << "Error: "<<e.what()<< std::endl;
              }
    
    return 0;
}