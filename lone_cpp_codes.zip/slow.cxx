#include <iostream>
#include <thread>
#include <chrono>

using namespace std;

int main() {
   this_thread::sleep_for(chrono::seconds(3));  // Pause for 3 seconds
   cout << "Hello, World!" << endl;
   return 0;
}
