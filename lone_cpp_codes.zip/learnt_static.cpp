#include <iostream>
#include <memory>

void Deez(){
    static int count = 1;
    
    if(count == 1){
    std::cout<<"Deez() function called: "<<count<<" time."<<std::endl;
    }
    else{
        std::cout<<"Deez() function called: "<<count<<" times."<<std::endl;
    }
    
    count++;
}

int main(){
    
    for(int x = 1; x <= 5; x++){
        Deez();
    }
    
    {
    int boy = 16;
    int &girl = boy;

    std::unique_ptr<int> p = std::make_unique<int>(++boy);
    
    std::unique_ptr<int> ptr = std::make_unique<int>(girl);
    
    std::cout<<"The boy is "<<*p<<".\nHe has a twin sister.\nTherefore his twin is also "<<*ptr<<"."<<std::endl; 
    }
    
    //Error:  `boy` variable isn't part of this scope anymore.
    //std::cout<<"The boy's age is: "<<boy;
}