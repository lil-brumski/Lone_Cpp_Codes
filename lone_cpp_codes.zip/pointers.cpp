#include <iostream>
#include <limits>

int main()
{
	int be = 66;
	int *ptr{new int{be += 1}};
	std::cout << "Pointer 1: " << *ptr << std::endl;

	int *p{nullptr};
	p = new int;
	int meh = 45;
	*p = meh;
	meh--;
	std::cout << "Pointer 2: " << *p << std::endl;
	std::cout << std::boolalpha;

	std::cout << "*ptr is not equal to *p: " << (*ptr != *p) << std::endl;

	delete ptr;
	ptr = nullptr;

	delete p;
	p = nullptr;

	if (ptr != nullptr || p != nullptr)
	{
		std::cout << "WTF" << std::endl;
		ptr = nullptr;
		p = nullptr;
	}

	std::cout << "Program was a success!" << std::endl;

	int bru = 51;
	ptr = new int;
	bru = bru + 5;
 *ptr = bru;
 
	std::cout << "Pointer value for `bru` is: " << *ptr << std::endl;

	delete ptr;
	ptr = nullptr;

	std::cout << "Program was a success!" << std::endl;

	//std::cout << "Don\'t";
	
	try{
		int ass = 10/0;
		std::cout<<ass;
	}
	catch(std::exception& ex){
		std::cout<<"Runtime error"<<ex.what()<<std::endl;
	}
	
}