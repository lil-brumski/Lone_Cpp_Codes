#include <iostream>
#include <chrono>
#include <ctime>

int main() {
    // Get the current time point
    auto currentTime = std::chrono::system_clock::now();

    // Convert the current time point to a time_t object
    std::time_t currentTime_t = std::chrono::system_clock::to_time_t(currentTime);

    // Convert the time_t object to a string representation
    std::cout << "Current time: " << std::ctime(&currentTime_t);

    return 0;
}