# Python code to call the add function from the embedded C++ code

# Import the embedded module
import embedded_module

# Call the add function defined in the embedded C++ code
result = embedded_module.add(3, 4)

# Print the result returned by the C++ function
print("Result:", result)