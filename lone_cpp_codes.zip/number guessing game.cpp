#include <iostream>

int main(){
	    
	    int ln = 21;	    
	    int tries = 5;	    
	    int ug;
	    std::cout<<"Enter a number: ";
	    std::cin>>ug;	
	        
	    while(ug != ln){
	              tries--;
	              if(tries == 0){
	                 	std::cout<<"You lose!"<<std::endl;
	                 	return 0;
	                }
	              std::cout<<"Enter the correct number: ";
	              std::cin>>ug;
	           }	
	           
	    std::cout<<"You win!"<<std::endl;
	    
	    return 0;
	        
}