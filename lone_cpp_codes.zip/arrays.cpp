#include <iostream>
//#include <memory>

int main(){
	   /*
	   int list[300];
	   for(size_t i = 0; i < 300; i++){
	   	  list[i] = i * 5;
	   }
	   
	   for(size_t j = 0; j < 300; j++){
	   	std::cout<<"list["<<j<<"] : "<<list[j]<<std::endl;
	   }
	   
	   int sum_array = 0;
	   for(size_t k = 0; k < 300; k++){
	   	     sum_array+=list[k];
	   }
	   
	   std::cout<<"The sum of the arrays is: "<<sum_array<<".\nThe size of this array is "<<sizeof(list)<<" bytes."<<std::endl;
	  
	   int sum{};
	   for(size_t i{1}; i<=1000; i++ ){
	   	     sum+=i;
	   }
	   std::cout<<"The sum of the first positive thousand numbers is: "<<sum<<"!"<<std::endl;
	   */
	   
	   
	   /*int be = 56;
	   int *ptr{nullptr};
	   ptr = new int;
	   ptr = &be;
	   be++;
	   std::cout<<"Pointer 1: "<<*ptr<<std::endl;
	   */
	   
	   int be = 66;
	   int *ptr{new int{be+=1}};
	   //ptr = new int;
	   //ptr = &be;
	   //be++;
	   std::cout<<"Pointer 1: "<<*ptr<<std::endl;
	   

	   
	   int *p{nullptr};
	   p = new int;	   
	   int meh = 45;
	    p = &meh;
	   //*p = 56;
	   meh--;
	   std::cout<<"Pointer 2: "<<*p<<std::endl;
	   std::cout<<std::boolalpha;
	   
	   std::cout<<"*ptr is not equal to *p: "<<(*ptr != *p)<<std::endl;
	   
	   delete ptr;
	   ptr = nullptr;
	   //ptr = new int;
	   
	   delete p;
	   p = nullptr;
	   //p = new int;
	   
	   std::cout<<"Hey 👋"<<std::endl;
	   /*char ratio[6] = {'H', 'e', 'l', 'l', 'o'};
	   std::cout<<ratio<<std::endl;
	   char *po = &ratio[1];
	   std::cout<<*po<<std::endl;
	   
	   const char *pointer{"Hello World!"};
	   std::cout<<"The message is: "<<pointer<<std::endl;
	   
	   int girl = 12;
	   int *pm = &girl;
	   girl++;
	   std::cout<<"The value of *pm is: "<<*pm<<std::endl;
	   std::cout<<std::boolalpha;
	   std::cout<<"&girl is equal to pm: "<<(&girl==pm)<<std::endl;
	   
	   int un = 999;
	   std::cout<<un<<std::endl;
	   */
}