#include <iostream>
#include <cmath>
#include <iomanip>

int main(){
	    std::cout<<"Getting logarithms of numbers. "<<std::endl;
	    
	    double base;
	    std::cout<<"Enter the base you want to work with: ";
	    std::cin>>base;
	    
	    double number;
	    std::cout<<"Enter the number that you want to check the log of in the base you inputted: ";
	    std::cin>>number;
	    
	    std::cout<<std::setprecision(4);
	    
	    std::cout<<"The log of "<<number<<" with a base of "<<base<<" is "<<std::log(number)/std::log(base)<<"!"<<std::endl;
	    char vat = 45;
	    char vatt = 55;
	    
	    auto vtt = vat + vatt;
	    std::cout<<vtt<<std::endl;
	    
	    
	    return 0; 
}