#include <iostream>
using namespace std;


//You are giving out biscuits to your dumb friends, if everyone can get an equal amount of biscuits then you should give them, but if they can't then eat them yourself hahahahahahaha
int main(){
	   cout << "You are giving out biscuits to your friends, if everyone can get an equal amount of biscuits then you should give them, but if they can't, eat them yourself! Hahahahahahaha."<<endl;
	   cout << "Warning: Enter only whole numbers!"<<endl;
	   cout << " "<<endl;
	   //Enter the no. of friend your are giving biscuits to. 
	   int friends;
	   cout << "Enter the no. of friends that you are giving biscuits to: ";
	   cin>>friends;
	   
	   //Enter the no. of biscuits you have. 
	   int biscuit;
	   cout << "Enter the no. of biscuits you have: ";
	   cin>>biscuit;
	   cout <<" "<<endl;
	   if(biscuit % friends == 0){
	   	  cout << "Give your friends the biscuits.";  
	   }
	   else{
	   	       cout << "Eat them yourself! Hahahahaha!";
	   }
	
	 if(biscuit==0){
	   	      cout << " Wait...you have no biscuits!";
	   }
	   
	   if(friends==0){
	   	  cout << " You don't have friends to give!";
	   }
	return 0;
}