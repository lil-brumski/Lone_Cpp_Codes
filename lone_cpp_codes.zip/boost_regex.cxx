#include <boost/regex.hpp>
#include <iostream>

int main() {
    std::string str = "hello hello world";
    boost::regex pattern("hello");

    // Search for a pattern in a string
    if (boost::regex_search(str, pattern)) {
        std::cout << "Pattern found!" << std::endl;
    }

    // Replace a pattern in a string
    std::string new_str = boost::regex_replace(str, pattern, "new");
    std::cout << new_str << std::endl; // Output: "new world"

    return 0;
}
