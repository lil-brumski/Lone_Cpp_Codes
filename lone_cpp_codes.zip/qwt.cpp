#include <iostream>
using namespace std;

int main(){
	    string animal = "Leopard";
	    string yourGuess;
	    int attempts= 3;
	    cout << "Animal guessing game. \nHINT: The animal is a wild cat.\nYou have 3 attempt(s).\n";
	    cin>>yourGuess;
	    while(yourGuess != animal ){
	    	         cout << "Wrong animal! ";   	         
	    	         cout<< --attempts<< " attempt(s) left"<<endl;
	    	         cin>>yourGuess;	 
	    	      // attempts;  
	    	         if(attempts ==1 && yourGuess != animal){
	    	         	 	     cout <<" You lose"<<endl; ;
	    	              return 0;	 
	    	           	} // cin>>yourGuess;       
	  }  
	    cout << "You win";
	    return 0;
}