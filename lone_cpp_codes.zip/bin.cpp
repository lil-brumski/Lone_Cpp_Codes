#include <iostream>
#include <bitset>
#include <sstream>

int main() {
    std::string binaryMessage = "01001000 01100101 01101100 01101100 01101111 00101100 00100000 01010111 01101111 01110010 01101100 01100100 00100001";
    
    std::istringstream ss(binaryMessage);
    std::string binaryChunk;
    
    while (ss >> binaryChunk) {
        char c = static_cast<char>(std::bitset<8>(binaryChunk).to_ulong());
        std::cout << c;
    }

    std::cout << std::endl;

    return 0;
}