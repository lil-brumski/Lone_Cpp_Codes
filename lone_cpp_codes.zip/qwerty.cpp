#include <iostream>
using namespace std;

//Guess the lucky number; you are to try and guess the lucky number for you to win a prize! 

int main()
{
	int luckyNum = 4;
	int players_num;
	cout << "Guess the number: ";
	cin >> players_num;
	while (players_num != luckyNum){
         			cout << "Try Again" << endl;
         			cin>>players_num;
         		}
            	cout << "You Win" << endl;
	 
        	return 0;
}
}