#include <iostream>
#include <string>
#include <map>

using namespace std;

map<string, string> responses = {
	{"hello", "Hello! How can I assist you?"},
	{"hi", "Hi! What's on your mind?"},
	{"how are you", "I'm doing well, thank you! I'm a large language model, so I don't have feelings like humans do."},
	{"goodbye", "Goodbye! It was nice chatting with you."}
};

int main() {
	string input;
	cout << "Welcome to the chatbot! Type 'quit' to exit." << endl;
	while (true) {
		cout << "You: ";
		getline(cin, input);
		if (input == "quit") {
			break;
		}
		if (responses.find(input) != responses.end()) {
			cout << "Chatbot: " << responses[input] << endl;
		}else {
			cout << "Chatbot: I didn't understand that. Please try again!" << endl;
		}
	}
	return 0;
}
