#include <iostream>
#include <cmath>
#include <string>

int main(){
	    char oper;
	    double num1;
	    double num2;
	    std::cout<<"Enter number: ";
	    std::cin>>num1;
	    std::cout<<"Enter operator (+, -, *, /, ^): ";
	    std::cin>>oper;
	    std::cout<<"Enter second number: ";
	    std::cin>>num2;
	    
	    if(oper == '+'){
	    	std::cout<<num1<<" + "<<num2<<" = ";
	    	std::cout<<num1 + num2<<std::endl;
	    }
	    else if(oper == '-'){
	    	std::cout<<num1<<" - "<<num2<<" = ";
	    	std::cout<<num1 - num2<<std::endl;
	    }
	    else if(oper == '*'){
	    	std::cout<<num1<<" * "<<num2<<" = ";
	    	std::cout<<num1 * num2<<std::endl;
	    }
	    else if(oper == '/'){
	    	    if(num2 != 0){
	           	std::cout<<num1<<" / "<<num2<<" = ";
	           	std::cout<<num1 / num2<<std::endl;
	    	    }
	    	    else{
	    	    	  std::cout<<"Bruh...are you trying to divide by zero 💀"<<std::endl;
	    	    }
	    }
	    else if(oper == '^'){
	    	std::cout<<num1<<" ^ "<<num2<<" = ";
	    	std::cout<<std::pow(num1,num2)<<std::endl;
	    }	
	    else{
	    	std::cout<<"Huh"<<std::endl;
	    	}    
	    return 0;
}
