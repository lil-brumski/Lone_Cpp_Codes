#include <iostream>
#include <limits>

template <typename T>
T getInput(const std::string& prompt) {
    T value;
    while (!(std::cout << prompt && std::cin >> value)) {
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cerr << "Invalid input. Please enter a valid value." << std::endl;
    }
    return value;
}

int main() {
    // Getting input for 10 different integers
    int num1 = getInput<int>("Enter integer 1: ");
    int num2 = getInput<int>("Enter integer 2: ");
    int num3 = getInput<int>("Enter integer 3: ");
    int num4 = getInput<int>("Enter integer 4: ");
    int num5 = getInput<int>("Enter integer 5: ");
    int num6 = getInput<int>("Enter integer 6: ");
    int num7 = getInput<int>("Enter integer 7: ");
    int num8 = getInput<int>("Enter integer 8: ");
    int num9 = getInput<int>("Enter integer 9: ");
    int num10 = getInput<int>("Enter integer 10: ");

    // Displaying the entered values
    std::cout << "Entered integers are: " << num1 << ", " << num2 << ", " << num3 << ", " << num4 << ", "
              << num5 << ", " << num6 << ", " << num7 << ", " << num8 << ", " << num9 << ", " << num10 << std::endl;

    return 0;
}