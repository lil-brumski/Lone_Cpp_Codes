#include <iostream>
#include <boost/math/special_functions/factorials.hpp>
#include <iomanip>

int main() {
    int n = 10;
    double factorial_n = boost::math::factorial<double>(n);

    std::cout << "Factorial of " << n << " is: " <<std::setprecision(20)<< factorial_n << std::endl;

    return 0;
}