//For inputting data and outputting data.
#include <iostream>
//For using some mathematical functions.
#include <cmath>
//For Input and Output Manipulation.
#include <iomanip>
//For managing the memory used by this program.
#include <memory>
//For using std::numeric_limits
#include <limits>
//For using a string of characters also known as words.
#include <string>
//For using std::vectors
#include <vector>


//When the user enters the wrong data type, it will prompt the user to try again until they enter it properly.
template <typename T>
  T getInput(const std::string& prompt){
      T value;
      std::cout<<prompt;
      while(!(std::cin>>value)){
          std::cin.clear();
          std::cin.ignore(std::numeric_limits<std::streamsize>::max(),'\n');
          std::cerr<<"Wrong input! Try again."<<std::endl;
      }
      return value;
  }


class Sine{
    private:
       double sinnum;
       
    public:
        double sinof;
        Sine(double si) : sinnum(si) {}
        void sn(){
            sinof = sinnum * ( M_PI / 180);
            std::cout<<"The sine of "<<sinnum<<" is "<<std::setprecision(3)<<std::sin(sinof)<<std::endl;
        }
};

//This is where the code runs.  
int main(){
   
   int tries = 3;
   while(true){   
            
            if(tries == 0){
                break;
             }
             
    double enter = getInput<double>("Enter a number: ");  
    
    {
        std::unique_ptr<Sine> ptr(new Sine(enter));
        ptr->sn();
    }
    
    tries--;
   }
    return 0;
}