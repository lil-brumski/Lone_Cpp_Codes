#include <iostream>
#include <fstream>
#include <string>

int main(){
    std::ifstream File("/storage/emulated/0/Documents/Cxxdroid/more on classes!.cpp");
    
    if(File.is_open()){
        std::string line;
        while(getline(File,line)){
            std::cout<<line<<std::endl;
        }
        File.close();
    }
    else{
        std::cerr<<"Couldn't open file sir."<<std::endl;
        return 1;
    }
    return 0;
}