#include <iostream>
#include <string>
#include <cctype>

int main() {
    std::string gender;

    // Prompt the user to enter their gender
    std::cout << "Gender: ";
    std::cin >> gender;

    // Convert the input to lowercase
    for (size_t i = 0; i < gender.length(); ++i) {
        gender[i] = std::tolower(gender[i]);
    }

    // Check if the gender matches the expected values
    if (gender == "male" || gender == "female") {
        // Gender is valid
        std::cout << "Valid gender!\n";
    } else {
        // Gender is invalid
        std::cout << "Invalid gender! Please enter either 'male' or 'female'.\n";
    }

    return 0;
}