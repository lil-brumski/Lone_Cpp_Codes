#include <iostream>

int sum(int a, int b){
    return (a+b);
}

int main(){
      int aaa, bbb;
      
      std::cout<<"Enter two numbers: ";
      
      std::cin>>aaa>>bbb;
      
      int lol = sum(aaa, bbb);
      
      std::cout<<"The sum of the two provided numbers is: "<<lol<<std::endl;
}