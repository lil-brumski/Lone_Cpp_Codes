#include <iostream>
using namespace std;


string doNut(string first_name, string last_name){
	          string full_name = first_name + " " + last_name;
	          return full_name;
}
int main(){
	   string a, b;
	   cin>>a>>b;
	   cout <<"Your name is "<<doNut(a,b)<<"."<<endl;
	   donut();
	   
	   return 0;
	
}