#include <iostream>
#include <limits>
#include <string>

template <typename T>
  T getInput(const std::string& prompt){
      T value;
      while(!(std::cout<<prompt && std::cin>>value)){
          std::cin.clear();
          std::cin.ignore(std::numeric_limits<std::streamsize>::max(),'\n');
          std::cerr<<"Invalid input!"<<std::endl;
      }
      return value;
  }

template <>
     std::string getInput<std::string>(const std::string& prompt){
         std::string value;
         std::cout<<prompt;
         std::cin.ignore();
         std::getline(std::cin,value);
         return value;
     }

int main(){
     std::string name, lastname;
     name = getInput<std::string>("Your first name? ");
     lastname = getInput<std::string>("Your last name? ");
     std::cout<<"You are "<<name<<" "<<lastname<<std::endl;
}