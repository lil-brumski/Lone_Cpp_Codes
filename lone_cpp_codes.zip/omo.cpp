// A simple guessing game in c++
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main()
{
    // Generate a random number between 1 and 10
    srand(time(0)); // Seed the random number generator
    int lucky_number = rand() % 10 + 1; // Get a random number in the range [1, 10]
    
    // Initialize the number of tries and the user's guess
    int tries = 0;
    int guess = 0;
    
    // Welcome the user and explain the rules
    cout << "Welcome to the guessing game!\n";
    cout << "You have to guess the lucky number between 1 and 10.\n";
    cout << "You have 3 tries to guess it correctly.\n";
    
    // Loop until the user guesses the lucky number or runs out of tries
    while (guess != lucky_number && tries < 3)
    {
        // Prompt the user to enter a guess
        cout << "Enter your guess: ";
        cin >> guess;
        
        // Check if the guess is valid
        if (guess < 1 || guess > 10)
        {
            cout << "Invalid guess. Please enter a number between 1 and 10.\n";
            continue; // Skip the rest of the loop and start over
        }
        
        // Increment the number of tries
        tries++;
        
        // Check if the guess is correct
        if (guess == lucky_number)
        {
            cout << "Congratulations! You guessed the lucky number!\n";
            break; // Exit the loop
        }
        else
        {
            // Give a hint to the user
            if (guess < lucky_number)
            {
                cout << "Your guess is too low.\n";
            }
            else
            {
                cout << "Your guess is too high.\n";
            }
            
            // Tell the user how many tries are left
            if (tries < 3)
            {
                cout << "You have " << 3 - tries << " tries left.\n";
            }
            else
            {
                cout << "Sorry, you ran out of tries. The lucky number was " << lucky_number << ".\n";
            }
        }
    }
    
    // Thank the user for playing and end the program
    cout << "Thank you for playing the guessing game!\n";
    return 0;
}
