//A code for getting factorial of the user's age. 
#include <iostream>

//Template for handling errors related to wrong data type input. 
template <typename T>
  T getInput(const std::string& prompt){
      T value;
      while(!(std::cout<<prompt && std::cin>>value)){
          std::cin.clear();
          std::cin.ignore(std::numeric_limits<std::streamsize>::max(),'\n');
          std::cerr<<"Invalid input, try again by entering an actual number.\n";
      }
      return value;
  }
 
//Main function. 
int main(){
      
      //Variable for storing the factorial. 
      unsigned long long facto = 1;
      
      //Variable for the user to enter their age. 
      int num = getInput<int>("Enter your age, let's get a factorial of that: ");
      
      //Checks if the age is negative. Only an Werey person will put their age as negative. 
      if(num >=  0){
           //Loop for getting the factorial. 
           for(size_t x = 1; x <= num; x++){
                  facto*=x;
         }  
         //Output .   
         std::cout<<"The factorial of your age is: "<<facto<<std::endl;
        } 
        //Message for weird ass people that put their age as negative. 
        else{
            std::cout<<"Did you really put a negative number as your age? 💀"<<std::endl;
        }
        
        //Shows that the program was successful.
        return 0;
}