#include <iostream>
#include <stdexcept>
#include <chrono>
#include <thread>

void Err(){  
  try{
	    	   double a;
	    	   double b;
	    	   std::cout<<"Enter 1st no.: ";
	    	   std::cin>>a;
	    	   std::cout<<"Enter 2nd no.: ";
	    	   std::cin>>b;
	    	   
	    	   if(b == 0){
	    	   	  throw 
	    	   	    std::runtime_error("Can't divide by zero");
	    	     }
	    	   double c = a / b;
	    	   std::cout<<"The value of c is: "<<c<<std::endl;
	    }
  catch(const std::exception& error){
	    	   	  std::cerr<<"Error: "<<error.what()<<std::endl;
	      }	    	   	
}

void Wait_(){
	       int wait = 5;
	       
	       std::cout<<"Wait..."<<std::endl;
	       
	       std::chrono::milliseconds duration(wait * 1000);
	       
	       std::this_thread::sleep_for(duration);
}

int main(){
	  
	  Wait_();
	  Err();
	  
}