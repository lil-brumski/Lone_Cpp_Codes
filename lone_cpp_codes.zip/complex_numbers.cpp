#include <iostream>
#include <complex>

int main() {
    std::complex<double> num = -4;
    std::complex<double> sqrt_num = std::sqrt(num);
    std::cout << "The square root of " << num.real() << " is " << sqrt_num.imag()<< "i" << std::endl;
    return 0;
}