#include <iostream>
#include <fstream>

int main() {
    std::ofstream outputFile("/storage/emulated/0/Documents/yees.py", std::ios::app); // Open a file for appending

    if (outputFile.is_open()) {
        for(int x = 0; x <100; x++){
        outputFile << "print(\"Hello world!\")" << std::endl;
        }
        outputFile.close(); // Close the file
        std::cout << "Data appended to the file." << std::endl;
    } else {
        std::cerr << "Unable to open the file for appending." << std::endl;
    }

    return 0;
}
