#include <iostream>

int main() {
    int age;
    
    while (!(std::cin >> age)) {
        std::cin.clear(); // Clear error flags
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Discard input buffer
        
        std::cout << "Invalid input. Please enter a valid age: ";
    }

    std::cout << "You're " << age << " years old!" << std::endl;

    return 0;
}