#include <iostream>
#include <cmath>
using namespace std;


int main(){
      char oper;
      double num1, num2;
      cin>>oper>>num1>>num2;

   switch(oper){
	            case '+':
	              cout << " "<<endl;
	              cout << num1 + num2;
	              break;
	            case '-':
	              cout << " "<<endl;
	              cout << num1 - num2;
	              break;
	            case '*':
	              cout << " "<<endl;
	              cout << num1 * num2;
	              break;
	            case '/':
	              if(num2 != 0){
	              	cout << " "<<endl;
	              	cout << num1 / num2;
	              	}
	              	 else	{
	              	 cout << " "<<endl;
	              		cout << "Can't divide by zero";
	              	}
	              	break;
	             case '^':
	                cout << " "<<endl;
	                cout << pow(num1, num2);
	                break;
	             default:
	               cout << " "<<endl;
	               
	              	cout << "Invalid operator";
	          }
	          return 0;     
	    }