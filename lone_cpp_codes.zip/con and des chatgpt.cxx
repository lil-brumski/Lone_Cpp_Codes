#include <iostream>

class MyClass {
public:
    // Constructor
    MyClass() {
        std::cout << "Constructor called!\n";
    }

    // Destructor
    ~MyClass() {
        std::cout << "Destructor called!\n";
    }
};

int main() {
    // Creating an object invokes the constructor
    MyClass myObject;

    // Object goes out of scope, invoking the destructor
    return 0;
}