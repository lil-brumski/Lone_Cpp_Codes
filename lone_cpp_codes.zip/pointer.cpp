#include <iostream>

int main(){
    int age = 15;
    int *ptr = &age;
    std::cout<<*ptr;
}