#include <iostream>
#include <string>
#include <sstream>
#include <iomanip>

int main() {
    double num = 1000000.00;

    // Create an output string stream
    std::ostringstream oss;

    // Set fixed format and precision to 2 decimal places
    oss << std::fixed << std::setprecision(2) << num;

    // Convert the stream to a string
    std::string str = oss.str();

    if(str.length() == 9){
        str.insert(3, ",");
        }
    else if(str.length() == 10){
        str.insert(1, ",");
        str.insert(5, ",");
     }
     
    std::cout << str << std::endl;

    return 0;
}
