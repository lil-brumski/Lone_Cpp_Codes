#include <iostream>
using namespace std;
int main (){
	    //Entry Message.
	    cout<<"Welcome to Brumsky! Sign Up to create an account: "<<endl;	    
	    cout<<" "<<endl;
	    //Prompts the users to enter their name.
	    string name;
	    cout<<"Full name: ";
	    getline(cin,name);
	    //Prompts the user to enter their age.
	    int age;
	    cout<<"You must be at least 13 years old to use this service.\n Enter your age: ";
	    cin>>age;
	    //Checks if their age is less than 13, if it is then the program will automatically end. When the user meets the age requirements, he/she will be allowed to continue.
	    while(age < 13){
	    	        cout<<"You do not meet the age requirements for this service!"<<endl;
	    	        return 0;
	    }
	      //Prompts the user to enter their email.
	    string email;
	    cout<<"Email address: ";
	    cin>>email;
	      //Prompts the user to enter their password.
	    string password;
	    cout<<"Password: ";
	    cin>>password;
	      //Prompts the user to confirm their password.
	    string confirm_password;
	    cout<<"Confirm your password: ";
	    cin>>confirm_password;
	    //If the two passwords don't match, he/she will be in a loop that can only be broken when the two passwords match.
	    while(confirm_password != password){
	    cout<<"Passwords don't match! Try again: ";
	    cin>>confirm_password;
	    }
	      //Prompts the user to enter their country.
	    string country;
	    cout<<"Nationality: ";
	    cin>>country;
	      //Prompts the user to enter their gender.
	    string gender;
	    cout<<"Enter your gender: ";
	    cin>>gender;
	    //If the user's gender input doesn't match the values inside this while loop, they will be stuck here until it matches.
	    while(gender != "male" && gender != "female" && gender != "Male" && gender != "Female"){
	    	        cout<<"Invalid gender! Try again: ";
	    	        cin>>gender;   
	    	        }
	    cout<<" "<<endl;
	    //The message below will show after the user has successfully created their account.
	    cout<<"You have successfully created your account!"<<endl;
	    
	    cout<<" "<<endl;
	    //The user will be asked to login again.
	    cout<<"Login: "<<endl;
	    cout<<" "<<endl;
	      //Prompts the user to enter their email.
	    string loginEmail;
	    cout<<"Enter your email: ";
	    cin>>loginEmail;
	      //Prompts the user to enter their password.
	    string loginPass;
	    cout<<"Key in your password: ";
	    cin>>loginPass;
	    //If either the entered email or password doesn't match the ones on lines 23 and 25 respectively, it won't allow the user to pass until both of them correct.
	    while(loginEmail != email || loginPass != password){
	    	         cout<<"Details not found! Try again."<<endl;;
	    	         cout<<"Enter your email: ";
	    cin>>loginEmail;
	           cout<<"Key in your password: ";
	    cin>>loginPass;
	    }
	    cout<<" "<<endl;
	    //When both fields are entered correctly, a message appears on the screen.
	    cout<<"Login Successful!"<<endl;	    
	    cout<<" "<<endl;
	    //The user's profile appears.
	    cout<<" "<<endl;
	    cout<<"USER PROFILE: "<<endl;
	    cout<<" "<<endl;	    
	    cout<<"Name: "<< name<<".\nAge: "<<age<<".\nGender: "<<gender<<".\nEmail Address: "<<email<<".\nCountry: "<<country<<"."<<endl;	    
	    return 0;	    	    
	}