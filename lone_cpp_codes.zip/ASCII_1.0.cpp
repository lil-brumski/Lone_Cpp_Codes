#include <iostream>
#include <string>
#include <iomanip>

int main(){
	    std::string name;
	    std::cout<<"Enter your name: ";
	    std::getline(std::cin,name);
	    
	    int age;
	    std::cout<<"Enter your age: ";
	    std::cin>>age;
	    
	    std::cout<<std::endl;
	    int wth = 35;
	    std::cout<<std::left;
	    std::cout<<std::setfill('.');
	    std::cout<<std::setw(wth)<<"Name:"<<std::setw(wth)<<name<<std::endl;
	    std::cout<<std::setw(wth)<<"Age:"<<std::setw(wth)<<age<<std::endl;
	    
	    std::cout<<std::endl;
	    std::cout<<"The space being used to store your name is "<<sizeof(name)<<" bytes!"<<std::endl;
	    
	    std::cout<<"The space being used to store your age is "<<sizeof(age)<<" bytes!"<<std::endl;
	    
}