#include <iostream>
#include <string>
#include <algorithm>

int main() {
    // Input string
    std::string input = "Hello World";

    // Character to be removed
    char charToRemove = 'o';

    // Remove all occurrences of the character
    input.erase(std::remove(input.begin(), input.end(), charToRemove), input.end());

    // Output the modified string
    std::cout << "Modified string: " << input << std::endl;

    return 0;
}
