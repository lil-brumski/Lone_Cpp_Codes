#include <iostream>

int main(){
	    
	    //Stores the factorial.
	    unsigned long long fact = 1;
	     
	     //Declaring the variable to store user input.
	    unsigned int user;
	    std::cout<<"Enter a number >= 1 and <= 20 that you want to get the factorial of: ";
	    std::cin>>user;
	    
	    //Conditional statement that checks user's input.
	    //If user's input is less than 1 or more than 20, it won't do any calculations.
	    if(user < 1 || user > 20){
	    	  std::cout<<"I can't do that bro"<<std::endl;
	    }
	    //If the user's input meets the criteria, it will execute.
	    else{
	           for(size_t i = user; i >= 1; i--){
	    	            fact*=i;
	                 }
	                 std::cout<<"The factorial of "<<user<<" is "<<fact;
	    }
	    
	    //Shows that the program was successful!	    
	    return 0;
}