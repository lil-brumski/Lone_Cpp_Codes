#include <iostream>
using namespace std;

int main(){
	    cout << "Pick a number between 30 and 89, you have 5 attempts."<<endl;
	    cout << "Winner gets a beautiful message...Just joking, you won't :)"<<endl;
	    cout << "Warning: Entering any value other than a number will result in the program prematurely ending."<<endl;
	    double number;
	    number = 67;
	    double guess;
	    cin>>guess;
	  /*  int attempts;
	    attempts = 5;*/
	    for(double attempts = 4; attempts>=0; --attempts){
	    	if(attempts!=0 && guess!=number){
	    		 cout <<"Try again, you have "<<attempts<<" attempts left.\n";
	    		 cin>>guess;
	    		 }
	  if(attempts==0 && guess!=number){
	    		cout <<"You lose!";
	    		return 0;
	    		}
	 	}
	
	    if(guess == number){
	    	cout << "You win!"<<endl;
	    	return 0;
	    	}
}