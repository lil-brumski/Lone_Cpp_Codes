#include <iostream>
#include <iomanip>
using namespace std;

int main(){
	    char hi[3][5] = {
{'D', 'a', 'v','i','d'} , 
{'T','a','r','e','&'}, 
{'B','r','u','m','e'}
};
cout<<"Size of hi array: "<<sizeof(hi)<<" bytes."<<endl;



int a(12);
int b(13);
cout<<a+b<<endl;;
cout << max(a,b)<<endl;
cout<<boolalpha;
cout<<((10>2)==true)<<endl;
cout<<15<<endl;//Decimal 
cout<<017<<endl;//Octal 
cout<<0x0f<<endl;//Hexadecimal
cout<<0b001111<<endl;//Binary
cout<<0b1100010<<endl;
cout<<"Size of this data type: "<<sizeof(long double)<<" bytes."<<endl;
char fu = 100;
cout<<fu<<endl<<'5'-'0'<<endl;
double num1,num2;
num1=5.0;
num2=9.0;
cout<<num2/num1<<endl;


cout<<left;
cout<<setfill('~');
cout<<setw(35)<<"Name"<<setw(7)<<"Age"<<endl;
cout<<setw(35)<<"David Tamaratare"<<setw(7)<<16<<endl;
cout<<setw(35)<<"David Tamaralayefa"<<setw(7)<<14<<endl;
cout<<setw(35)<<"David Tejiri"<<setw(7)<<19<<endl;

cout<<" "<<endl;
cout<<"I"<<" I\'m"<<" here"<<endl;
int maintain=45;
cout<<showbase;
cout<<uppercase;
cout<<showpos;
cout<<maintain<<endl;
cout<<hex<<maintain<<endl;
cout<<"hi"<<endl;
cout<<noshowbase<<noshowpos;
int meth= 67;
meth = 64;
cout<<dec<<meth<<endl;
return 0;

}
