#include <iostream>
#include <fstream>

int main(){
     
     std::ofstream file("/storage/emulated/0/Documents/c++_is_awesome.txt");// ,std::ios::app);
     
     if(file.is_open()){
         for(int x = 1; x <1001; x++){
         file<<x<<".Hey there!"<<std::endl;
         }
         file.close();
         std::cout<<"File appended!"<<std::endl;
     }
     else{
         std::cerr<<"Unable to open file :("<<std::endl;
     }
     
}