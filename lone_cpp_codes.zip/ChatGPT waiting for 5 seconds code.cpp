#include <iostream>
#include <chrono>
#include <thread>

int main() {
    int seconds_to_wait = 10; // Change this to the number of seconds you want to wait
    
    std::cout << "Waiting for " << seconds_to_wait << " seconds..." << std::endl;
    
    // Convert seconds to milliseconds for std::this_thread::sleep_for
    std::chrono::milliseconds duration(seconds_to_wait * 1000);
    
    // Sleep for the specified duration
    std::this_thread::sleep_for(duration);
    
    std::cout << "Finished waiting!" << std::endl;
    
    return 0;
}