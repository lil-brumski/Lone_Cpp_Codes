#include <iostream>
#include <cmath>
#include <iomanip>
//using namespace std;


//Write a random word.


int main(){
     std::cout<<std::log(7)/std::log(3)<<std::endl;
     int num{23};
     int *p = &num;
     *p=7;
     num+=6;
     std::cout<<*p<<std::endl;
     std::cout<<std::setprecision(4);
     double numBer = 111.27827;
     std::cout<<numBer<<std::endl;
     std::cout<<sizeof(long double)<<std::endl;
     std::cout<<(0.1+0.2==0.3)<<std::endl;
    /* unsigned int boyageu;
     std::cin>>boyageu;
        if (boyageu < 0){
     	       std::cerr<<"error";
            }
        else{
                std::cout<<boyageu;
               }*/
      std::cout<<"Size of signed int: "<<sizeof(signed int)<<" bytes"<<std::endl;
      std::cout<<std::setprecision(20); 
      double check{10e9};
      std::cout<<check<<std::endl;
      //double ratio;
      //std::cin>>ratio;
      std::cout<<std::boolalpha;
      int meth = 87;
      int colos = 8;
      if(meth > colos){
      	std::cout<<true;
      }
      else{
      	std::cout<<false;
      }
      std::cout<<" "<<std::endl;
      //std::cout<<std::noboolalpha;
      std::cout<<(true==71)<<std::endl;
      char fff = 40;
      std::cout<<fff;
      return 0 ;
}