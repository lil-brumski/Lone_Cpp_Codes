#ifndef DEEZ_NUTS
#define DEEZ_NUTS

#include <iostream>

class Deez{
    public:
      Deez(){
          //std::cout<<"Deez Con\n";
      }
      virtual void show(){
          std::cout<<"Deez\n";
      }
      virtual ~Deez(){
          //std::cout<<"Deez Des\n";
      }
};

class Baby: public Deez{
    public:
      Baby(){
          //std::cout<<"Baby Con\n";
      }
      void show() override {
          std::cout<<"Baby\n";
      }
      ~Baby(){
          //std::cout<<"Baby Des\n";
      }
};

#endif