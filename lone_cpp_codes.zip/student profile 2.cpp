#include <iostream>
using namespace std;
/*Their numbers are de.100, de.101, de.102, de.103, de.104.
*/
void de100(){
	          cout <<"Name: David Jack.\nStudent No: de.100.\nAge: 16.\nGender: Male.\nCGPA: 3.70."<<endl;
}
void de101(){
	          cout <<"Name: Daniel Jones.\nStudent No: de.101.\nAge: 19.\nGender: Male.\nCGPA: 4.63.\nClass: 100 level."<<endl;
}
void de102(){
	          cout <<"Name: Maria Martins.\nStudent No: de.102.\nAge: 15.\nGender: Female.\nCGPA: 4.21.\nClass: 100 level."<<endl;
}
void de103(){
	          cout <<"Name: Angel Melissa.\nStudent No: de.102.\nAge: 16.\nGender: Female.\nCGPA: 3.98.\nClass: 100 level."<<endl;
}
void de104(){
	          cout <<"Name: Annie Jaegar.\nStudent No: de.104.\nAge: 17.\nGender: Female.\nCGPA: 4.98.\nClass: 100 level."<<endl;
}

int main(){
	   string search;
	   cout<<" Search for a student, enter their student number: ";
	   cin>>search;
	   
	   cout<<" "<<endl;
	   
	   if(search == "de.100"){
	   	    de100();
	   }
	   else if(search == "de.101"){
	   	    de101();
	   }
	   else if(search == "de.102"){
	   	    de102();
	   }
	   else if(search == "de.103"){
	   	    de103();
	   }
	   else if(search == "de.104"){
	   	    de104();
	   }
	   else {
	   	    cout<<"Student not found! Try again: ";
	   	    cin>>search;
	   	     
	   if(search == "de.100"){
	   	    de100();
	   }
	   else if(search == "de.101"){
	   	    de101();
	   }
	   else if(search == "de.102"){
	   	    de102();
	   }
	   else if(search == "de.103"){
	   	    de103();
	   }
	   else if(search == "de.104"){
	   	    de104();
	   }
	   else {
	   	    cout<<"Student not found!";
	   	    return 0;
	   }
  }
     
      cout<<"Do you wish to search for more students? Send \'yes\' to continue or send \'no\' to end this program: ";
        string search2;
	   	    cin>>search2;
	   	    if( search2 == "yes"){
	   	    	   cout<<" Search for a student, enter their student number: ";
	   	    	   cin>>search;
	   	    	        if(search == "de.100"){
	   	                  de100();
	                  }
	                  else if(search == "de.101"){
	   	                  de101();
	                   }
	                    else if(search == "de.102"){
	   	                      de102();
	                    }
	                      else if(search == "de.103"){
	   	                      de103();
	                    }
	                       else if(search == "de.104"){
	   	                        de104();
	                      }
	                       else {
	   	                     cout<<"Student not found! Try again: ";
	   	                       cin>>search;
	                          }
	   	                   }
	     else if(search2 == "no"){
	   	    	        return 0;
	      }
	   	    
	   	 else{
	   	    	   cout<<"That was not even in the options 😡";
	   	    	   return 0;
	   	    }
	   	    
	   	    
	   
}
	   
