#include <iostream>
#include <string>
int main(){
	    std::string name;
	    std::cout<<"Enter your name: ";
	    std::getline(std::cin,name);
	    int space;
	    std::cout<<"How many spaces did you use to separate your name?: ";
	    std::cin>>space;
	    std::cout<<"Your name is "<<name<<"."<<std::endl;
	    std::cout<<"The length of your name is "<<name.length()-space<<" letters!"<<std::endl;
}