#include <iostream>
#include <memory>

class Enemy {
public:
    virtual void attack() {
        std::cout << "Enemy!" << std::endl;
    }
    virtual ~Enemy() {} // Don't forget virtual destructor for polymorphic behavior
};

class Ninja : public Enemy {
public:
    void attack() override {
        std::cout << "Ninja!" << std::endl;
    }
};

class Monster : public Enemy {
public:
    void attack() override {
        std::cout << "Monster!" << std::endl;
    }
};

int main() {
    std::unique_ptr<Enemy> n = std::make_unique<Ninja>();
    
    std::unique_ptr<Enemy> m = std::make_unique<Monster>();
    
    std::unique_ptr<Enemy> e = std::make_unique<Enemy>();

    n->attack(); // Outputs "Ninja!"
    m->attack(); // Outputs "Monster!"
    e->attack(); // Outputs "Enemy!"
}