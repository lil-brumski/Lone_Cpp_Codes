#include <iostream>

int main() {
    int luckyNum = 23;
    int guess;
    int attempts = 5;

    std::cout << "Guess the lucky number (between 1 and 100): ";

    while (attempts > 0) {
        std::cin >> guess;

        if (guess == luckyNum) {
            std::cout << "Congratulations! You guessed it right!" << std::endl;
            return 0; // End the program
        } else {
            std::cout << "Try again. Attempts left: " << --attempts << std::endl;
        }
    }

    std::cout << "Sorry, you've run out of attempts. The lucky number was: " << luckyNum << std::endl;
    return 0;
}