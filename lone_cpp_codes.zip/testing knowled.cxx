#include <iostream>
#include <limits>
#include <chrono>
#include <thread>

template <typename T>
  T getInput(const std::string& prompt){
      T value;
      while(!(std::cout<<prompt && std::cin>>value)){
          std::cin.clear();
          std::cin.ignore(std::numeric_limits<std::streamsize>::max(),'\n');
          std::cerr<<"Invalid input, try again!"<<std::endl;
      }
      return value;
  }
  
void Ti(){
    int wait = 5;
    std::cout<<"Hold on..."<<std::endl;
    
    std::chrono::milliseconds duration(1000*wait);
    std::this_thread::sleep_for(duration);
    
    std::cout<<"Done waiting!"<<std::endl;
}

int main(){
      Ti();
      int age = getInput<int>("Enter your age: ");
      std::cout<<"You are: "<<age<<"\n";
}